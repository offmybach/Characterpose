PROGRAM IN A BOX - DEPLOYMENT INSTRUCTIONS
===========================================

WHAT CHANGED:
- clarence-gets-a-bargain.html: 6 "Download" buttons now link to
  interactive landing pages instead of PDFs
- resources/ folder: 6 new HTML landing pages

FILES TO ADD/REPLACE:
1. REPLACE: clarence-gets-a-bargain.html (updated links)
2. ADD FOLDER: resources/ (with all 6 HTML files inside)

IN CLAUDE CODE:
1. Open the update-magazine-cover branch
2. Copy clarence-gets-a-bargain.html to replace existing
3. Create resources/ folder, copy all 6 HTML files in
4. git add .
5. git commit -m "Replace PDF downloads with interactive landing pages"
6. git push

NOTE: The main site still has 8 references to kidsmoneybook.com
in email addresses (orders@kidsmoneybook.com etc). Update those
if/when the email addresses change to @clarencegetsabargain.com.
